package com.example.hito1;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class IncidenciaDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "incidencias.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_INCIDENCIAS = "incidencias";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_TITULO = "titulo";
    public static final String COLUMN_DESCRIPCION = "descripcion";
    public static final String COLUMN_URGENCIA = "urgencia";
    public static final String COLUMN_EVIDENCIA = "evidencia";
    public static final String COLUMN_LAT = "lat";
    public static final String COLUMN_LON = "lon";

    private static final String TABLE_CREATE =
            "CREATE TABLE " + TABLE_INCIDENCIAS + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_TITULO + " TEXT, " +
                    COLUMN_DESCRIPCION + " TEXT, " +
                    COLUMN_URGENCIA + " INTEGER, " +
                    COLUMN_EVIDENCIA + " TEXT, " +
                    COLUMN_LAT + " REAL, " +
                    COLUMN_LON + " REAL);";

    public IncidenciaDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INCIDENCIAS);
        onCreate(db);
    }
}
