package com.example.hito1;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private IncidenciaDAO incidenciaDAO;
    private RecyclerView recyclerView;
    private IncidenciaAdapter adapter;
    private List<Incidencia> incidenciaList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Verifica si el usuario está autenticado
        SharedPreferences prefs = getSharedPreferences("user_data", MODE_PRIVATE);
        boolean isLoggedIn = prefs.getBoolean("is_logged_in", false);  // Verifica el estado de inicio de sesión

        if (!isLoggedIn) {
            // Si no está autenticado, redirige al LoginActivity
            Intent loginIntent = new Intent(this, LoginActivity.class);
            startActivity(loginIntent);
            finish();  // Asegúrate de cerrar MainActivity para que no vuelva al inicio
            return;
        }

        // Si está autenticado, muestra la pantalla principal (incidencias)
        setContentView(R.layout.activity_main);

        // Inicializamos el RecyclerView
        recyclerView = findViewById(R.id.recycler_view);

        // Inicializamos la lista de incidencias
        incidenciaList = new ArrayList<>();

        // Inicializamos el DAO
        incidenciaDAO = new IncidenciaDAO(this);

        // Verificar si la base de datos tiene datos antes de insertar la incidencia de prueba
        if (incidenciaDAO.obtenerTodasLasIncidencias().isEmpty()) {
            Incidencia incidencia = new Incidencia("Bache en la calle", "Descripción del bache", 3, "foto_bache.jpg", 19.432608, -99.133209);
            incidenciaDAO.insertarIncidencia(incidencia);
        }

        // Cargar todas las incidencias de la base de datos
        incidenciaList = incidenciaDAO.obtenerTodasLasIncidencias();

        // Configuramos el LayoutManager y el Adapter
        recyclerView.setLayoutManager(new LinearLayoutManager(this));  // Muestra la lista de manera vertical
        adapter = new IncidenciaAdapter(incidenciaList);  // Pasamos la lista de incidencias al Adapter
        recyclerView.setAdapter(adapter);  // Asignamos el Adapter al RecyclerView

        // Actualizamos el RecyclerView
        adapter.notifyDataSetChanged();  // Notificamos que los datos han cambiado
    }
}
