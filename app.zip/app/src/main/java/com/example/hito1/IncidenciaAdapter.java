package com.example.hito1;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class IncidenciaAdapter extends RecyclerView.Adapter<IncidenciaAdapter.IncidenciaViewHolder> {

    private List<Incidencia> incidencias;

    public IncidenciaAdapter(List<Incidencia> incidencias) {
        this.incidencias = incidencias;
    }

    @Override
    public IncidenciaViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // Inflamos el layout del item
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_incidencia, parent, false);
        return new IncidenciaViewHolder(view);
    }

    @Override
    public void onBindViewHolder(IncidenciaViewHolder holder, int position) {
        // Vinculamos los datos a las vistas
        Incidencia incidencia = incidencias.get(position);
        holder.titulo.setText(incidencia.getTitulo());
        holder.descripcion.setText(incidencia.getDescripcion());
    }

    @Override
    public int getItemCount() {
        return incidencias.size();  // Retorna el tamaño de la lista
    }

    // ViewHolder para los items
    public class IncidenciaViewHolder extends RecyclerView.ViewHolder {
        TextView titulo, descripcion;

        public IncidenciaViewHolder(View itemView) {
            super(itemView);
            // Aquí aseguramos que los IDs coincidan con los del XML
            titulo = itemView.findViewById(R.id.titulo);
            descripcion = itemView.findViewById(R.id.descripcion);
        }
    }
}
