package com.example.hito1;

public class Incidencia {
    private String titulo;
    private String descripcion;
    private int urgencia;
    private String evidencia;
    private double latitud;
    private double longitud;

    // Constructor
    public Incidencia(String titulo, String descripcion, int urgencia, String evidencia, double latitud, double longitud) {
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.urgencia = urgencia;
        this.evidencia = evidencia;
        this.latitud = latitud;
        this.longitud = longitud;
    }

    // Getters y setters
    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public int getUrgencia() { return urgencia; }
    public void setUrgencia(int urgencia) { this.urgencia = urgencia; }

    public String getEvidencia() { return evidencia; }
    public void setEvidencia(String evidencia) { this.evidencia = evidencia; }

    public double getLatitud() { return latitud; }
    public void setLatitud(double latitud) { this.latitud = latitud; }

    public double getLongitud() { return longitud; }
    public void setLongitud(double longitud) { this.longitud = longitud; }
}

