package com.example.hito1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import java.util.ArrayList;
import java.util.List;

public class IncidenciaDAO {

    private static SQLiteDatabase database;
    private static IncidenciaDatabase dbHelper;

    public IncidenciaDAO(Context context) {
        if (dbHelper == null) {
            dbHelper = new IncidenciaDatabase(context.getApplicationContext());
        }
    }

    public SQLiteDatabase getDatabase() {
        if (database == null || !database.isOpen()) {
            database = dbHelper.getWritableDatabase();
        }
        return database;
    }

    public void insertarIncidencia(Incidencia incidencia) {
        SQLiteDatabase db = getDatabase();
        try {
            ContentValues values = new ContentValues();
            values.put(IncidenciaDatabase.COLUMN_TITULO, incidencia.getTitulo());
            values.put(IncidenciaDatabase.COLUMN_DESCRIPCION, incidencia.getDescripcion());
            values.put(IncidenciaDatabase.COLUMN_URGENCIA, incidencia.getUrgencia());
            values.put(IncidenciaDatabase.COLUMN_EVIDENCIA, incidencia.getEvidencia());
            values.put(IncidenciaDatabase.COLUMN_LAT, incidencia.getLatitud());
            values.put(IncidenciaDatabase.COLUMN_LON, incidencia.getLongitud());

            long result = db.insert(IncidenciaDatabase.TABLE_INCIDENCIAS, null, values);

            if (result == -1) {
                Log.e("IncidenciaDAO", "Error al insertar la incidencia");
            } else {
                Log.d("IncidenciaDAO", "Incidencia insertada correctamente");
            }
        } catch (Exception e) {
            Log.e("IncidenciaDAO", "Error al insertar incidencia: " + e.getMessage());
        }
    }

    public List<Incidencia> obtenerTodasLasIncidencias() {
        List<Incidencia> incidencias = new ArrayList<>();
        SQLiteDatabase db = getDatabase();
        Cursor cursor = null;

        try {
            cursor = db.query(
                    IncidenciaDatabase.TABLE_INCIDENCIAS,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null
            );

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    String titulo = cursor.getString(cursor.getColumnIndex(IncidenciaDatabase.COLUMN_TITULO));
                    String descripcion = cursor.getString(cursor.getColumnIndex(IncidenciaDatabase.COLUMN_DESCRIPCION));
                    int urgencia = cursor.getInt(cursor.getColumnIndex(IncidenciaDatabase.COLUMN_URGENCIA));
                    String evidencia = cursor.getString(cursor.getColumnIndex(IncidenciaDatabase.COLUMN_EVIDENCIA));
                    double lat = cursor.getDouble(cursor.getColumnIndex(IncidenciaDatabase.COLUMN_LAT));
                    double lon = cursor.getDouble(cursor.getColumnIndex(IncidenciaDatabase.COLUMN_LON));

                    Incidencia incidencia = new Incidencia(titulo, descripcion, urgencia, evidencia, lat, lon);
                    incidencias.add(incidencia);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e("IncidenciaDAO", "Error al obtener incidencias: " + e.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }

        return incidencias;
    }
}
